import shutil
import datetime
import os

def backup_files(source, destination):
    today = datetime.date.today()
    backup_name = os.path.join(destination, f"backup_{today}")

    try:
        shutil.make_archive(backup_name,'gztar', source)
        print(f"Backup created successfully: {backup_name}")
    except Exception as e:
        print(f"Error creating backup: {e}")

source_dir = "/home/harshit/Desktop/python_devops"
destination_dir = "/home/harshit/Desktop/python_devops/backups"
backup_files(source_dir, destination_dir)