print("Hello Dosto")

name = "Harshit"
print("My name is",name)

# Output:
"""

Hello Dosto
My name is Shubham

"""