"""
range() function
range(start, stop, step)
start: starting number of the sequence
stop: generate numbers up to, but not including this number
step: difference between each number in the sequence

"""
print(range(10))

# First 9 numbers
for i in range(10):
    print(i)

# first 10 even numbers
for i in range(0,20,2):
    print(i)
